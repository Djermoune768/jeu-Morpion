package application;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Modality;
import javafx.scene.Node;
import javafx.event.ActionEvent;

import java.io.IOException;
import java.net.URL;

public class AccueilControleur {

    @FXML
    private TextField pseudoField;
    String aide = "Jeu des 15 :\n\n"
            + "Le but est d’obtenir une somme de 15\n"
            + "en choisissant trois chiffres.\n"
            + "Vous jouez contre l’ordinateur.\n\n"
            + "À chaque tour, choisissez un chiffre\n"
            + "parmi ceux disponibles (1 à 9).\n"
            + "Chaque chiffre ne peut être utilisé\n"
            + "qu’une seule fois.\n\n"
            + "Pour jouer :\n"
            + "- Saisir un chiffre\n"
            + "- Cliquer sur \"Valider\"\n\n"
            + "Fin de partie :\n"
            + "- Somme = 15 → victoire\n"
            + "- L’ordinateur gagne → défaite\n"
            + "- Aucun gagnant → égalité\n\n"
            + "Morpion :\n\n"
            + "Jeu sur une grille 3 × 3.\n"
            + "Alignez 3 symboles :\n"
            + "- Horizontalement\n"
            + "- Verticalement\n"
            + "- Diagonale\n\n"
            + "Grille pleine sans alignement :\n"
            + "match nul.\n\n"
            + "Besoin d’aide ?\n"
            + "+33 6 99 99 99 99";

    @FXML
    private void handleJouer(ActionEvent event) throws IOException {
        String nomJoueur = pseudoField.getText().trim();
        if (nomJoueur.isEmpty()) {
            nomJoueur = "joueur";
        }
        GestionOptions.getInstance().setPseudo(nomJoueur);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("boutons.fxml"));
        Parent root = loader.load();

        Scene scene = new Scene(root);
        appliquerTheme(scene);
        appliquerTaillePolice(scene);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleOption(ActionEvent event) throws IOException {
        String nomJoueur = pseudoField.getText().trim();
        if (nomJoueur.isEmpty()) {
            nomJoueur = "joueur";
        }
        GestionOptions.getInstance().setPseudo(nomJoueur);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("option.fxml"));
        Parent root = loader.load();

        Scene sceneOptions = new Scene(root);
        appliquerTheme(sceneOptions);

        Stage optionsStage = new Stage();
        optionsStage.setTitle("Options");
        optionsStage.setScene(sceneOptions);
        optionsStage.initModality(Modality.APPLICATION_MODAL);
        optionsStage.showAndWait();
        Scene sceneAccueil = pseudoField.getScene();
        appliquerTheme(sceneAccueil);
        appliquerTaillePolice(sceneAccueil);
    }

    @FXML
    private void handleAide() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Aide");
        alert.setHeaderText("Règles du jeu:");
        alert.setContentText(aide);
     
        alert.showAndWait();
    }

    @FXML
    private void handleQuitter() {
        Platform.exit();
    }

    private void appliquerTheme(Scene scene) {
        scene.getStylesheets().clear();

        String css = "/theme_bleu.css";
        if ("rose".equals(GestionOptions.getInstance().getTheme())) {
            css = "/theme_rose.css";
        }

        java.net.URL url = getClass().getResource(css);
        if (url != null) {
            scene.getStylesheets().add(url.toExternalForm());
        } else {
            System.out.println("CSS introuvable : " + css);
        }
       
    }
    private void appliquerTaillePolice(Scene scene) {
        double taille = GestionOptions.getInstance().getTaillePolice();
        scene.getRoot().setStyle("-fx-font-size: " + taille + "px;");
    }
    
    
    
}