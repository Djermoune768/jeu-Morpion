package application;

public class GestionOptions {

    private String pseudo = "joueur";
    private String theme = "bleu";
    private String jeu = "15"; // "15" ou "morpion"
    private double taillePolice = 14.0;

    // singleton pour accéder partout
    private static GestionOptions instance = new GestionOptions();

    public static GestionOptions getInstance() {
        return instance;
    }

    public String getPseudo() { return pseudo; }
    public void setPseudo(String pseudo) { this.pseudo = pseudo; }

    public String getTheme() { return theme; }
    public void setTheme(String theme) { this.theme = theme; }

    public String getJeu() { return jeu; }
    public void setJeu(String jeu) { this.jeu = jeu; }

    public double getTaillePolice() { return taillePolice; }
    public void setTaillePolice(double taillePolice) { this.taillePolice = taillePolice; }

    public void reinitialiser() {
        pseudo = "joueur";
        theme = "bleu";
        jeu = "15";
        taillePolice = 14.0;
    }
}