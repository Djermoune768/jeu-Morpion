package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("accueil.fxml"));
        Scene scene = new Scene(root);

        appliquerTheme(scene);

        primaryStage.setTitle("Jeu des 15");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    private void appliquerTheme(Scene scene) {
        scene.getStylesheets().clear();

        String css = "/theme_bleu.css";
        if ("rose".equals(GestionOptions.getInstance().getTheme())) {
            css = "/theme_rose.css";
        }

        URL url = getClass().getResource(css);
        if (url != null) {
            scene.getStylesheets().add(url.toExternalForm());
        } else {
            System.out.println("CSS introuvable : " + css);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}