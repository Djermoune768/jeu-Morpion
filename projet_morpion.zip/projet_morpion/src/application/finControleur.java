package application;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class finControleur {

    @FXML private Label place;
    @FXML private Label place2;
    @FXML private ImageView image;

    public void setResultat(int jeuFini) {
        if (jeuFini == 1) {
            place.setText("Bravo! ");
            place2.setText("Bravo ! Vous avez gagné !\n Mais est-ce que vous pouvez l'emporter une nouvelle fois ?\n");
            image.setImage(new Image(getClass().getResourceAsStream("/win.png")));
        } else if (jeuFini == 2) {
            place.setText("Dommage ! ");
            place2.setText("Je vous ai battu à plate couture ...\n Serez-vous capable de prendre votre revanche ?");
            image.setImage(new Image(getClass().getResourceAsStream("/perdu.png")));
        } else if (jeuFini == 3) {
            place.setText("Égalité ! ");
            place2.setText("Nous sommes de force égale...\n pour l'instant. Qui va enfin prendre l'avantage ?");
            image.setImage(new Image(getClass().getResourceAsStream("/egalite.png")));
        }
    }
}