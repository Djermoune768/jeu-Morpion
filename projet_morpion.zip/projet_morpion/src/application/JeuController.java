package application;

public class JeuController {
	GestionJeu jeu=new GestionJeu();
	public void setNomJoueur(String nom) {
		this.jeu.set_nomJoueur(nom);
	}

}
