package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import java.util.Vector;

public class morpionControleur {

    private GestionJeu jeu = new GestionJeu();
    private boutonsControleur parentControleur;

    @FXML private RadioButton jouerEnRouge;
    @FXML private Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;
    @FXML private Label pseudo;
    @FXML private Label zone1;
    @FXML private Label zone2;

    private int compteurJoueur = 0;
    private int compteurOrdi = 0;
    private int jeuFini = 0;
    private Vector<Integer> v = new Vector<Integer>();

    public void setParentControleur(boutonsControleur ctrl) {
        this.parentControleur = ctrl;
    }

    @FXML
    public void initialize() {
        pseudo.setText(GestionOptions.getInstance().getPseudo());
        btn1.getStyleClass().add("btn-morpion");
        btn2.getStyleClass().add("btn-morpion");
        btn3.getStyleClass().add("btn-morpion");
        btn4.getStyleClass().add("btn-morpion");
        btn5.getStyleClass().add("btn-morpion");
        btn6.getStyleClass().add("btn-morpion");
        btn7.getStyleClass().add("btn-morpion");
        btn8.getStyleClass().add("btn-morpion");
        btn9.getStyleClass().add("btn-morpion");

        zone1.setStyle("-fx-background-color: green; -fx-background-radius: 5px; -fx-min-width: 25px; -fx-min-height: 25px;");
        zone2.setStyle("-fx-background-color: red; -fx-background-radius: 5px; -fx-min-width: 25px; -fx-min-height: 25px;");

        jouerEnRouge.selectedProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal) {
                zone1.setStyle("-fx-background-color: red; -fx-background-radius: 5px; -fx-min-width: 25px; -fx-min-height: 25px;");
                zone2.setStyle("-fx-background-color: green; -fx-background-radius: 5px; -fx-min-width: 25px; -fx-min-height: 25px;");
            } else {
                zone1.setStyle("-fx-background-color: green; -fx-background-radius: 5px; -fx-min-width: 25px; -fx-min-height: 25px;");
                zone2.setStyle("-fx-background-color: red; -fx-background-radius: 5px; -fx-min-width: 25px; -fx-min-height: 25px;");
            }
        });
    }

    @FXML
    private void cliquer(javafx.event.ActionEvent e) {
        if (jeuFini != 0) return;

        Button btn = (Button) e.getSource();
        int chiffre = getChiffre(btn);

        if (!jeu.EstChiffreDispo(chiffre)) return;

        jouerEnRouge.setDisable(true);

        jeu.ChiffrePris(1, chiffre);
        btn.getStyleClass().clear();
        if (jouerEnRouge.isSelected()) {
            btn.getStyleClass().add("btn-morpion-rouge");
        } else {
            btn.getStyleClass().add("btn-morpion-vert");
        }
        btn.setDisable(true);
        compteurJoueur++;

        v.clear();
        jeuFini = jeu.FinJeu(v);

        if (jeuFini == 0 && !jeu.ChiffresDispos()) {
            parentControleur.afficherFin(3);
            return;
        }

        if (jeuFini == 0) {
            jouerOrdi();
        }

        if (jeuFini != 0) {
            parentControleur.afficherFin(jeuFini);
        }
    }

    private void jouerOrdi() {
        if (!jeu.ChiffresDispos()) {
            parentControleur.afficherFin(3);
            return;
        }

        int choix = jeu.ChoixOrdinateur();
        jeu.ChiffrePris(2, choix);

        Button btn = getButton(choix);
        if (btn != null) {
            btn.getStyleClass().clear();
            if (jouerEnRouge.isSelected()) {
                btn.getStyleClass().add("btn-morpion-vert");
            } else {
                btn.getStyleClass().add("btn-morpion-rouge");
            }
            btn.setDisable(true);
        }
        compteurOrdi++;

        v.clear();
        jeuFini = jeu.FinJeu(v);

        if (jeuFini == 0 && !jeu.ChiffresDispos()) {
            parentControleur.afficherFin(3);
            return;
        }

        if (jeuFini != 0) {
            parentControleur.afficherFin(jeuFini);
        }
    }

    private Button getButton(int n) {
        switch (n) {
            case 1: return btn1;
            case 2: return btn2;
            case 3: return btn3;
            case 4: return btn4;
            case 5: return btn5;
            case 6: return btn6;
            case 7: return btn7;
            case 8: return btn8;
            case 9: return btn9;
        }
        return null;
    }

    private int getChiffre(Button btn) {
        if (btn == btn1) return 1;
        if (btn == btn2) return 2;
        if (btn == btn3) return 3;
        if (btn == btn4) return 4;
        if (btn == btn5) return 5;
        if (btn == btn6) return 6;
        if (btn == btn7) return 7;
        if (btn == btn8) return 8;
        if (btn == btn9) return 9;
        return -1;
    }
}