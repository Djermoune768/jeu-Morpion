package application;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class optionsControleur {

    private boutonsControleur parentControleur;

    @FXML private TextField pseudoField;
    @FXML private RadioButton radioJeu15;
    @FXML private RadioButton radioMorpion;
    @FXML private SplitMenuButton themeMenu;
    @FXML private Slider tailleSlider;

    private GestionOptions options = GestionOptions.getInstance();

    private String themeTemp;
    private String jeuTemp;
    private double tailleTemp;

    public void setParentControleur(boutonsControleur ctrl) {
        this.parentControleur = ctrl;
    }

    @FXML
    public void initialize() {
        pseudoField.setText(options.getPseudo());

        jeuTemp = options.getJeu();
        themeTemp = options.getTheme();
        tailleTemp = options.getTaillePolice();

        if (jeuTemp.equals("15")) {
            radioJeu15.setSelected(true);
        } else {
            radioMorpion.setSelected(true);
        }

        themeMenu.setText(themeTemp.equals("bleu") ? "Theme Bleu" : "Theme Rose");
        tailleSlider.setValue(tailleTemp);

        tailleSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            double valeur = Math.round(newVal.doubleValue());

            if (valeur < 12) valeur = 12;
            if (valeur > 16) valeur = 16;

            tailleTemp = valeur;
        });
    }

    @FXML
    private void valider() {
        String nomJoueur = pseudoField.getText().trim();
        if (nomJoueur.isEmpty()) {
            nomJoueur = "joueur";
        }

        jeuTemp = radioJeu15.isSelected() ? "15" : "morpion";


        options.setPseudo(nomJoueur);
        options.setJeu(jeuTemp);
        options.setTheme(themeTemp);
        options.setTaillePolice(tailleTemp);

        Stage stage = (Stage) pseudoField.getScene().getWindow();
        stage.close();

        if (parentControleur != null) {
            parentControleur.appliquerOptions();
        }
    }

    @FXML
    private void annuler() {
        Stage stage = (Stage) pseudoField.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void reinitialiser() {
        pseudoField.setText("joueur");
        radioJeu15.setSelected(true);
        themeMenu.setText("Theme Bleu");
        tailleSlider.setValue(14.0);

        themeTemp = "bleu";
        jeuTemp = "15";
        tailleTemp = 14.0;
    }

    @FXML
    private void themeBleu() {
        themeTemp = "bleu";
        themeMenu.setText("Theme Bleu");
    }

    @FXML
    private void themeRose() {
        themeTemp = "rose";
        themeMenu.setText("Theme Rose");
    }
}