package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import java.util.Vector;

public class controleur15 {

    private GestionJeu jeu = new GestionJeu();
    private boutonsControleur parentControleur;

    @FXML private Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;
    @FXML private Label zone1, zone2, zone3;
    @FXML private Label zone1ordi, zone2ordi, zone3ordi;
    @FXML private Label pseudo;

    private int compteurJoueur = 0;
    private int compteurOrdi = 0;
    private int jeuFini = 0;
    private Vector<Integer> v = new Vector<Integer>();

    public void setParentControleur(boutonsControleur ctrl) {
        this.parentControleur = ctrl;
    }

    @FXML
    public void initialize() {
        pseudo.setText(GestionOptions.getInstance().getPseudo());
    }

    @FXML
    private void cliquer(javafx.event.ActionEvent e) {
        if (jeuFini != 0) return;

        Button btn = (Button) e.getSource();
        int chiffre = Integer.parseInt(btn.getText());

        if (!jeu.EstChiffreDispo(chiffre)) return;

        // Tour du joueur
        jeu.ChiffrePris(1, chiffre);
        afficherJoueur(chiffre);
        btn.setVisible(false);

        // Vérifier si le joueur a gagné
        v.clear();
        jeuFini = jeu.FinJeu(v);
        if (jeuFini != 0) {
            parentControleur.afficherFin(jeuFini);
            return;
        }

        // Au 3ème clic du joueur → fin de partie sans victoire
        if (compteurJoueur >= 3) {
            parentControleur.afficherFin(3); // match nul ou fin forcée
            return;
        }

        // Vérifier match nul (plus de chiffres dispo)
        if (!jeu.ChiffresDispos()) {
            parentControleur.afficherFin(3);
            return;
        }

        // Tour de l'ordinateur
        jouerOrdi();
    }

    private void afficherJoueur(int chiffre) {
        if (compteurJoueur == 0) zone1.setText(String.valueOf(chiffre));
        else if (compteurJoueur == 1) zone2.setText(String.valueOf(chiffre));
        else if (compteurJoueur == 2) zone3.setText(String.valueOf(chiffre));
        compteurJoueur++;
    }

    private void jouerOrdi() {
        if (compteurOrdi >= 3) {
            parentControleur.afficherFin(3);
            return;
        }

        if (jeu.ChiffresDispos()) {
            int choix = jeu.ChoixOrdinateur();
            jeu.ChiffrePris(2, choix);
            afficherOrdi(choix);
            Button btn = getButton(choix);
            if (btn != null) btn.setVisible(false);

            v.clear();
            jeuFini = jeu.FinJeu(v);

            if (jeuFini == 0 && !jeu.ChiffresDispos()) {
                parentControleur.afficherFin(3);
                return;
            }

            if (jeuFini != 0) {
                parentControleur.afficherFin(jeuFini);
            }
        }
    }

    private void afficherOrdi(int chiffre) {
        if (compteurOrdi == 0) zone1ordi.setText(String.valueOf(chiffre));
        else if (compteurOrdi == 1) zone2ordi.setText(String.valueOf(chiffre));
        else if (compteurOrdi == 2) zone3ordi.setText(String.valueOf(chiffre));
        compteurOrdi++;
    }

    private Button getButton(int n) {
        switch (n) {
            case 1: return btn1;
            case 2: return btn2;
            case 3: return btn3;
            case 4: return btn4;
            case 5: return btn5;
            case 6: return btn6;
            case 7: return btn7;
            case 8: return btn8;
            case 9: return btn9;
        }
        return null;
    }
}