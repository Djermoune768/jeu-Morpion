package application;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.Modality;

import java.io.IOException;
import java.net.URL;

public class boutonsControleur {

    @FXML private Button btnPlay;
    @FXML private Button btnOptions;
    @FXML private Button btnQuit;
    @FXML private Button btnRules;
    @FXML private Pane zoneContenu;
    String aide = "Jeu des 15 :\n\n"
            + "Le but est d’obtenir une somme de 15\n"
            + "en choisissant trois chiffres.\n"
            + "Vous jouez contre l’ordinateur.\n\n"
            + "À chaque tour, choisissez un chiffre\n"
            + "parmi ceux disponibles (1 à 9).\n"
            + "Chaque chiffre ne peut être utilisé\n"
            + "qu’une seule fois.\n\n"
            + "Pour jouer :\n"
            + "- Saisir un chiffre\n"
            + "- Cliquer sur \"Valider\"\n\n"
            + "Fin de partie :\n"
            + "- Somme = 15 → victoire\n"
            + "- L’ordinateur gagne → défaite\n"
            + "- Aucun gagnant → égalité\n\n"
            + "Morpion :\n\n"
            + "Jeu sur une grille 3 × 3.\n"
            + "Alignez 3 symboles :\n"
            + "- Horizontalement\n"
            + "- Verticalement\n"
            + "- Diagonale\n\n"
            + "Grille pleine sans alignement :\n"
            + "match nul.\n\n"
            + "Besoin d’aide ?\n"
            + "+33 6 99 99 99 99";
    @FXML
    public void initialize() {
        chargerJeu();
    }

    @FXML
    private void jouer() {
        chargerJeu();
    }

    @FXML
    public void ouvrirOptions() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("option.fxml"));
            Parent root = loader.load();

            optionsControleur ctrl = loader.getController();
            ctrl.setParentControleur(this);

            Scene scene = new Scene(root);
            appliquerTheme(scene);
            appliquerTaillePolice(scene);

            Stage optionsStage = new Stage();
            optionsStage.setTitle("Options");
            optionsStage.setScene(scene);
            optionsStage.initModality(Modality.APPLICATION_MODAL);
            optionsStage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
            afficherErreur("Impossible de charger option.fxml : " + e.getMessage());
        }
    }

    @FXML
    private void afficherRegles() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Aide");
        alert.setHeaderText("Règles du jeu:");
        alert.setContentText(aide);
        alert.showAndWait();
    }

    @FXML
    private void quitter() {
        Platform.exit();
    }

    public void appliquerOptions() {
        if (zoneContenu != null && zoneContenu.getScene() != null) {
            Scene scene = zoneContenu.getScene();
            appliquerTheme(scene);
            appliquerTaillePolice(scene);
        }
        chargerJeu();
    }

    public void fermerOptions() {
        appliquerThemeSceneCourante();
        chargerJeu();
    }

    public void afficherFin(int jeuFini) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("fin.fxml"));
            Pane finPane = loader.load();

            finControleur ctrl = loader.getController();
            ctrl.setResultat(jeuFini);

            finPane.prefWidthProperty().bind(zoneContenu.widthProperty());
            finPane.prefHeightProperty().bind(zoneContenu.heightProperty());

            zoneContenu.getChildren().clear();
            zoneContenu.getChildren().add(finPane);

        } catch (IOException e) {
            e.printStackTrace();
            afficherErreur("Impossible de charger fin.fxml : " + e.getMessage());
        }
    }

    private void chargerJeu() {
        try {
            GestionOptions options = GestionOptions.getInstance();
            FXMLLoader loader;

            if (options.getJeu().equals("15")) {
                loader = new FXMLLoader(getClass().getResource("15.fxml"));
                Pane jeuPane = loader.load();
                controleur15 ctrl = loader.getController();
                ctrl.setParentControleur(this);

                jeuPane.prefWidthProperty().bind(zoneContenu.widthProperty());
                jeuPane.prefHeightProperty().bind(zoneContenu.heightProperty());

                zoneContenu.getChildren().clear();
                zoneContenu.getChildren().add(jeuPane);

            } else if (options.getJeu().equals("morpion")) {
                loader = new FXMLLoader(getClass().getResource("morpion.fxml"));
                Pane jeuPane = loader.load();
                morpionControleur ctrl = loader.getController();
                ctrl.setParentControleur(this);

                jeuPane.prefWidthProperty().bind(zoneContenu.widthProperty());
                jeuPane.prefHeightProperty().bind(zoneContenu.heightProperty());

                zoneContenu.getChildren().clear();
                zoneContenu.getChildren().add(jeuPane);
            }

        } catch (IOException e) {
            e.printStackTrace();
            afficherErreur("Impossible de charger le jeu : " + e.getMessage());
        }
    }

    private void appliquerThemeSceneCourante() {
        if (zoneContenu != null && zoneContenu.getScene() != null) {
            appliquerTheme(zoneContenu.getScene());
        }
    }

    private void appliquerTheme(Scene scene) {

        scene.getStylesheets().clear();

        String css;

        if ("rose".equals(GestionOptions.getInstance().getTheme())) {
            css = "/theme_rose.css";
        } else {
            css = "/theme_bleu.css";
        }

        scene.getStylesheets().add(
            getClass().getResource(css).toExternalForm()
        );
            }
    private void appliquerTaillePolice(Scene scene) {
        double taille = GestionOptions.getInstance().getTaillePolice();
        scene.getRoot().setStyle("-fx-font-size: " + taille + "px;");
    }

    private void afficherErreur(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erreur");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}